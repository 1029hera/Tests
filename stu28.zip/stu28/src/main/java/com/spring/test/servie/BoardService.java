package com.spring.test.servie;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.test.domain.WriteDAO;
import com.spring.test.domain.WriteDTO;

@Service
public class BoardService {
	WriteDAO dao;
	
	// MyBatis
		private SqlSession sqlSession;
		
		@Autowired
		public void setSqlSession(SqlSession sqlSession) {
			this.sqlSession = sqlSession;
		}

		// �׽�Ʈ ���
		public BoardService() {
			super();
			System.out.println("BoardService() ����");
		}
		
		public List<WriteDTO> list(){
			// MyBatis �� ������� DAO
			dao = sqlSession.getMapper(WriteDAO.class);
			return dao.select();
		}
		
		public int write(WriteDTO dto) {
			dao = sqlSession.getMapper(WriteDAO.class);
			//return dao.insert(dto);
			
			int result = dao.insert(dto);
			System.out.println("������ uid �� " + dto.getMid());
			
			return result;
			
			//return dao.insert(dto.getSubject(), dto.getContent(), dto.getName());
		}
		
		//@Transactional
		public List<WriteDTO> viewByMid(int mid){
			dao = sqlSession.getMapper(WriteDAO.class); // MyBatis ���
			return dao.selectByMid(mid);
		}
		
		public List<WriteDTO> selectByMid(int mid) {
			dao = sqlSession.getMapper(WriteDAO.class); // MyBatis ���
			return dao.selectByMid(mid);  // 1��¥�� List
		}
		
		public int update(WriteDTO dto) {
			dao = sqlSession.getMapper(WriteDAO.class); // MyBatis ���
			//return dao.update(dto);
			return dao.update(dto.getMid(), dto);
		}
		
		public int deleteByMid(int mid) {
			dao = sqlSession.getMapper(WriteDAO.class); // MyBatis ���
			return dao.deleteByMid(mid);				
		}
}
