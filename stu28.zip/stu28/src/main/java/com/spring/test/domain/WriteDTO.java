package com.spring.test.domain;

public class WriteDTO {
	private int mid;
	private String mname;
	private String mtype;
	private int mprice;
	
	public WriteDTO() {
		super();
	}
	
	public WriteDTO(int mid, String mname, String mtype, int mprice) {
		super();
		this.mid = mid;
		this.mname = mname;
		this.mtype = mtype;
		this.mprice = mprice;
	}
	
	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getMtype() {
		return mtype;
	}

	public void setMtype(String mtype) {
		this.mtype = mtype;
	}

	public int getMprice() {
		return mprice;
	}

	public void setMprice(int mprice) {
		this.mprice = mprice;
	}
	
	@Override
	public String toString() {
		return String.format("WriteDTO] %d : %s : %s : %d", 
				mid, mname, mtype, mprice);
	}
	
	
}
