package com.spring.test.domain;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.mybatis.spring.annotation.MapperScan;

@MapperScan
public interface WriteDAO {
	List<WriteDTO> select();
	
	// �����ۼ� <-- DTO
	int insert(WriteDTO dto);
	int insert(String mname, String mtype,  int mprice);
	
	List<WriteDTO> selectByMid(int mid);
		
	int update(WriteDTO dto);
	
	int update(int mid, @Param("a") WriteDTO dto);
	
	// Ư�� mid �� �����ϱ�
	int deleteByMid(int mid);
	
	WriteDTO searchByMname(String mname);
}
