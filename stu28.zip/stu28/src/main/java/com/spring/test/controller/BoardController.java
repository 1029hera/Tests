package com.spring.test.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.spring.test.TestValidator;
import com.spring.test.domain.WriteDTO;
import com.spring.test.servie.BoardService;

@Controller
@RequestMapping("/board")
public class BoardController {
private BoardService boardService;
	
	@Autowired
	public void setBoardService(BoardService boardService) {
		this.boardService = boardService;
	}
	

	public BoardController() {
		System.out.println("BoardController() ����");
	}
	
	@RequestMapping("/list.do")
	public String list(Model model) {
		model.addAttribute("list", boardService.list());
		return "board/list";
	}
	
	@RequestMapping("/write.do")
	public String write(Model model) {
		return "board/write";
	}
	
	@RequestMapping("/writeOk.do")
	public String writeOk(@ModelAttribute("w") @Valid WriteDTO dto, Model model,
			BindingResult result) {  // <- validator �� ��ȿ�� �˻縦 �� ����� ��� ��ü
		System.out.println("writeOk(): " + dto.getMid() + ":" + dto.getMname());
		
		System.out.print("validate�� "); showErrors(result);
		
		String page = "board/writeOk";
		
		if(result.hasErrors()) { // ������ �־�����
			page = "board/write";  // ���� ������ ���ư���
		}
		model.addAttribute("result", boardService.write(dto));
		
		return page;
	}
	
	@GetMapping("/view.do")
	public String view(int mid, Model model) {
		model.addAttribute("list", boardService.viewByMid(mid));
		return "board/view";
	}
	
	@RequestMapping("/update.do")
	public String update(int mid, Model model) {
		model.addAttribute("list", boardService.selectByMid(mid));		
		return "board/update";
	}

	@PostMapping("/updateOk.do")
	public String updateOk(@ModelAttribute("w") @Valid WriteDTO dto, Model model,
			BindingResult result) {
		System.out.println("updateOk(): " + dto.getMid() + ":" + dto.getMname());
		
		System.out.print("validate�� "); showErrors(result);
		
		String page = "board/updateOk";
		
		if(result.hasErrors()) { // ������ �־�����
			page = "board/update";  // ���� ������ ���ư���
		}
		
		model.addAttribute("result", boardService.update(dto));
		
		return page;
	}

	@GetMapping("/deleteOk.do")
	public String deleteOk(int mid, Model model) {
		model.addAttribute("result", boardService.deleteByMid(mid));
		return "board/deleteOk";
	}
	
	//  ���� ��� ����� �޼ҵ�
	public void showErrors(Errors errors) {
		if(errors.hasErrors()) {
			System.out.println("���� ���� : " + errors.getErrorCount());
			System.out.println("\t[field]\t|[code]");
			List<FieldError> errList = errors.getFieldErrors();
			for(FieldError err : errList) {
				System.out.println("\t" + err.getField() + "\t|" + err.getCode());
			}
		} else {
			System.out.println("���� ���");
		}
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.setValidator(new TestValidator());
	}
	
	
}
