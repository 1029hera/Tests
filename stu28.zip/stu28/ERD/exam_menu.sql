
/* Drop Tables */

DROP TABLE exam_menu CASCADE CONSTRAINTS;

/* Drop Sequences */

DROP SEQUENCE exam_menu_seq;




/* Create Tables */

CREATE TABLE exam_menu
(
	mid integer NOT NULL,
	mname varchar2(40) NOT NULL,
	mtype varchar2(20),
	mprice number DEFAULT 0,
	PRIMARY KEY (mid),
	CONSTRAINT menuType CHECK(mtype IN ('�ѽ�', '�߽�', '�Ͻ�')),
	CONSTRAINT menuPrice CHECK(mprice >= 0)
);

/* Create Sequences */

CREATE SEQUENCE exam_menu_seq;


INSERT INTO exam_menu (mid, mname, mtype, mprice) 
VALUES (exam_menu_seq.nextval, '��ġ', '�ѽ�', 500);

SELECT * FROM EXAM_MENU;
